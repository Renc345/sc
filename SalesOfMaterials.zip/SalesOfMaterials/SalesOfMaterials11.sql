CREATE DATABASE SalesOfMaterial;
USE SalesOfMaterial;

CREATE TABLE Employee
(
	IdEmployee INT PRIMARY KEY IDENTITY,
	FIO NVARCHAR(MAX),
	Login_Employee NVARCHAR(MAX),
	Password_Employee NVARCHAR(MAX),
	IdTypesEmployee INT REFERENCES TypesEmployee (IdTypesEmployee)
)

CREATE TABLE TypesEmployee
(
	IdTypesEmployee INT PRIMARY KEY IDENTITY,
	Nazv_type NVARCHAR(MAX)
)

Create Table ExpenseComposition
(
	IdExpenseComposition INT PRIMARY KEY IDENTITY,
	IdExpenseIvoices INT REFERENCES  ExpenseIvoices(IdExpenseIvoices),
	IdMaterial INT,
	Quantity INT,
	Price float
)

Create Table ExpenseIvoices
(
	IdExpenseIvoices INT PRIMARY KEY IDENTITY,
	Id�ounterparties INT REFERENCES  �ounterparties(Id�ounterparties),
	IdEmployee INT REFERENCES  Employee(IdEmployee),
	Date_Transfer date,
	DistributedInvoice BIT
)

Create Table �ounterparties
(
	Id�ounterparties  INT PRIMARY KEY IDENTITY,
	Nazv_�ounterparties  NVARCHAR(MAX),
	INN NVARCHAR(12),
	Adress_�ounterparties NVARCHAR(MAX)
)