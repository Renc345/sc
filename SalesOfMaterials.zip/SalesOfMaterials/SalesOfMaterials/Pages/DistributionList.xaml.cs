﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для DistributionList.xaml
    /// </summary>
    public partial class DistributionList : Page
    {
        public ExpenseComposition _currentItem = new ExpenseComposition();
        public DistributionList()
        {
            InitializeComponent();
            dgMovement.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.ExpenseIvoices.DistributedInvoice == false).ToList();
            cmbWarehouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses").ToList();
        }

        private void dgMovement_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            _currentItem = dgMovement.SelectedItem as ExpenseComposition;
            if (_currentItem != null)
            {
                foreach (Warehouses w in cmbWarehouse.ItemsSource)
                {
                    int i = ClassFrame.db.Database.SqlQuery<int?>("select Quantity from Nomenclature.dbo.Storage where idWarehouse = @idW and idMaterial = @idM", new SqlParameter("@idW", w.idWarehouse), new SqlParameter("@idM", _currentItem.IdMaterial)).FirstOrDefault() == null
                        ? 0 : ClassFrame.db.Database.SqlQuery<int>("select Quantity from Nomenclature.dbo.Storage where idWarehouse = @idW and idMaterial = @idM", new SqlParameter("@idW", w.idWarehouse), new SqlParameter("@idM", _currentItem.IdMaterial)).FirstOrDefault();
                    if (i > 0)
                    {
                        txtMaterials.Text = _currentItem.Material.Name;
                        txtApplication.Text = Convert.ToString(_currentItem.IdExpenseIvoices);
                        cmbWarehouse.SelectedItem = w;
                        MessageBox.Show($"Количество материала на складе: {i}", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }
                }
                MessageBox.Show("Такого материала нет на складах.", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                cmbWarehouse.SelectedIndex = -1;
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void MenuDistribute_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtQuantity.Text))
            {
                MessageBox.Show("Поле количество на раcпределение пустое", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (Convert.ToInt32(txtQuantity.Text) > _currentItem.DifferenceQuantity)
            {
                MessageBox.Show("Количество на раcпределение не может быть больше количества для распределения", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            Warehouses w = cmbWarehouse.SelectedItem as Warehouses;
            try
            {
                ClassFrame.db.Database.ExecuteSqlCommand("insert into Nomenclature.dbo.Movement values (@warehouse,@composition,@user,@quantity,1)", new SqlParameter("@warehouse", w.idWarehouse), new SqlParameter("@composition", _currentItem.IdExpenseComposition), new SqlParameter("@user", Users.GetUsers.ID), new SqlParameter("@quantity", Convert.ToInt32(txtQuantity.Text)));
                ClassFrame.db.Database.ExecuteSqlCommand("update Nomenclature.dbo.Storage set Quantity = Storage.Quantity - @quantity where idMaterial = @material and idWarehouse = @warehouse", new SqlParameter("@quantity", Convert.ToInt32(txtQuantity.Text)), new SqlParameter("@material", _currentItem.IdMaterial), new SqlParameter("@warehouse", w.idWarehouse));
                ClassFrame.db.Database.ExecuteSqlCommand("delete Nomenclature.dbo.Storage where idMaterial = @material and Quantity = 0 and idWarehouse = @warehouse", new SqlParameter("@material", _currentItem.IdMaterial), new SqlParameter("@warehouse", w.idWarehouse));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            if (_currentItem.DifferenceQuantity != 0)
            {
                cmbWarehouse.SelectedIndex++;
                w = cmbWarehouse.SelectedItem as Warehouses;
                int i = ClassFrame.db.Database.SqlQuery<int?>("select Quantity from Nomenclature.dbo.Storage where idWarehouse = @idW and idMaterial = @idM", new SqlParameter("@idW", w.idWarehouse), new SqlParameter("@idM", _currentItem.IdMaterial)).FirstOrDefault() == null
                        ? 0 : ClassFrame.db.Database.SqlQuery<int>("select Quantity from Nomenclature.dbo.Storage where idWarehouse = @idW and idMaterial = @idM", new SqlParameter("@idW", w.idWarehouse), new SqlParameter("@idM", _currentItem.IdMaterial)).FirstOrDefault();
                MessageBox.Show($"Количество материала на складе: {i}", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                MessageBox.Show("Успешно распределенно");
                _currentItem = null;
            }
            dgMovement.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.ExpenseIvoices.DistributedInvoice == false).ToList();
            txtQuantity.Text = "";
        }

        private void MenuСheck_Click(object sender, RoutedEventArgs e)
        {
            _currentItem = dgMovement.SelectedItem as ExpenseComposition;
            if (_currentItem == null)
            {
                MessageBox.Show($"Позиция не выбрана.", "Уведомление", MessageBoxButton.OK);
                return;
            }
            List<ExpenseComposition> list = ClassFrame.db.ExpenseComposition.Where(x => x.IdExpenseIvoices == _currentItem.IdExpenseIvoices).ToList();
            foreach (ExpenseComposition expense in list)
            {
                int? d = ClassFrame.db.Database.SqlQuery<int?>($"select sum(PartOfQuantity) from Nomenclature.dbo.Movement where idComposition = {expense.IdExpenseComposition} and ArrivalOrExpenditure = 1").Single();
                if (d == null) d = 0;
                if (d != expense.Quantity)
                {
                    MessageBox.Show($"Товар \"{expense.Material.Name}\" не закрыт.", "Уведомление", MessageBoxButton.OK);
                    return;
                }
            }
            try
            {
                ClassFrame.db.ExpenseIvoices.FirstOrDefault(x => x.IdExpenseIvoices == _currentItem.IdExpenseIvoices).DistributedInvoice = true;
                ClassFrame.db.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            MessageBox.Show("Заказ закрыт", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
            dgMovement.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.ExpenseIvoices.DistributedInvoice == false).ToList();
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgMovement.ItemsSource = ClassFrame.db.ExpenseComposition.Where(x => x.ExpenseIvoices.DistributedInvoice == false).ToList();
            cmbWarehouse.ItemsSource = ClassFrame.db.Database.SqlQuery<Warehouses>("select * from Nomenclature.dbo.Warehouses").ToList();
        }
        private void Back_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}
