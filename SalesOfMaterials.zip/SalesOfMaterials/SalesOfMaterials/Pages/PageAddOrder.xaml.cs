﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddOrder.xaml
    /// </summary>
    public partial class PageAddOrder : Page
    {
        public ExpenseIvoices _currentItem = new ExpenseIvoices();
        public PageAddOrder(ExpenseIvoices selectedItem)
        {
            InitializeComponent();
            if (selectedItem != null)
            {
                _currentItem = selectedItem;
            }
            DataContext = _currentItem;
            txtFIO.Text = Users.GetUsers.FIO;
            cmbСounterparties.ItemsSource = ClassFrame.db.Сounterparties.ToList();
            
        }

        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            if (cmbСounterparties.Text == "" && datePicker1.Text == "")
            {
                MessageBox.Show("Введите данные в поле", "Ошибка ввода", MessageBoxButton.OK, MessageBoxImage.Error);
                return;                   
            }
            _currentItem.IdСounterparties = ((Classes.Сounterparties)cmbСounterparties.SelectedItem).IdСounterparties;
            _currentItem.IdEmployee = Users.GetUsers.ID;
            _currentItem.Date_Transfer = datePicker1.SelectedDate;
            _currentItem.DistributedInvoice = false;
            if (_currentItem.IdExpenseIvoices == 0) ClassFrame.db.ExpenseIvoices.Add(_currentItem);
            try
            {
                ClassFrame.db.SaveChanges();
                ClassFrame.frmObj.Navigate(new PageAddExpenseComposition(_currentItem.IdExpenseIvoices));
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageOrder());
        }
    }
}
