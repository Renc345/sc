﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для ListOfMaterials.xaml
    /// </summary>
    public partial class ListOfMaterials : Page
    {
        public ListOfMaterials()
        {
            InitializeComponent();
            dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
        }

        private void dgStorage_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (dgStorage.SelectedItem != null)
            {
                Storage s = (Storage)dgStorage.SelectedItem;
                if (Convert.ToString(s.Material.DrawingNumber) == "Отсутствует")
                {
                    MessageBox.Show("Нельзя посмотреть так как номер чертежа отсутствует", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                else
                {
                    ClassFrame.frmObj.Navigate(new PageStructure(s.idMaterial));
                }
            }
        }

        private void btnDelet_Click(object sender, RoutedEventArgs e)
        {
            List<Storage> delet = dgStorage.SelectedItems.Cast<Storage>().ToList();
            if(MessageBox.Show("Удалить данные","Внимание",MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    foreach (Storage s in delet) ClassFrame.db.Database.ExecuteSqlCommand("delete from Nomenclature.dbo.Storage where idStorage = @id", new SqlParameter("@id", s.idStorage));
                    dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
                    MessageBox.Show("Данные удаленны");
                    
                }
                catch ( Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }

        private void txtDrawingNumber_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (TxtDrawingNumber.Text.Count() != 0) dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>($"select S.* from Nomenclature.dbo.Storage S join Nomenclature.dbo.Materials M on S.idMaterial = M.idMaterial where M.DrawingNumber like '%{TxtDrawingNumber.Text.ToLower()}%'").ToList();
            else dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
        }

        private void MenuFilter_Click(object sender, RoutedEventArgs e)
        {
            MenuItem m = sender as MenuItem;
            switch (m.Header)
            {
                case "Изделие":
                    dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.Material.Type.Name == "Изделие").ToList();
                    break;
                case "Узел":
                    dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.Material.Type.Name == "Узел").ToList();
                    break;
                case "Деталь":
                    dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.Material.Type.Name == "Деталь").ToList();
                    break;
                case "Материал":
                    dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").Where(x => x.Material.Type.Name == "Материал").ToList();
                    break;
            }
        }

        private void MenuClear_Click(object sender, RoutedEventArgs e)
        {
            dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
        }

        private void MenuUpdate_Click(object sender, RoutedEventArgs e)
        {
            dgStorage.ItemsSource = ClassFrame.db.Database.SqlQuery<Storage>("select * from Nomenclature.dbo.Storage").ToList();
        }

        private void Back1_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMenu());
        }
    }
}
