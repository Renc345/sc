﻿using SalesOfMaterials.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SalesOfMaterials.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAuthorization.xaml
    /// </summary>
    public partial class PageAuthorization : Page
    {
        public PageAuthorization()
        {
            InitializeComponent();
            login.Text = "";
            password.Password = "";
        }

        private void btnenter_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (login.Text == "") MessageBox.Show("Заполните поле логин", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
                if (password.Password == "") MessageBox.Show("Заполните поле пароль", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
                else
                {
                    Employee employee = ClassFrame.db.Employee.FirstOrDefault(x => x.Login_Employee == login.Text && x.Password_Employee == password.Password);
                    if (employee == null) MessageBox.Show("Неверный логин или пароль", "Ошибка ввода данных", MessageBoxButton.OK, MessageBoxImage.Error);
                    else
                    {
                        Users _user = new Users(employee);
                        ClassFrame.frmObj.Navigate(new PageMenu());
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnregistration_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageRegistration());
        }
    }
}
