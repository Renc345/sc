﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Movement
    {
        public int idMovement { get; set; }
        public int idWarehouse { get; set; }
        public int idComposition { get; set; }
        public int idUser { get; set; }
        public int PartOfQuantity { get; set; }
        public bool ArrivalOrExpenditure { get; set; }

        public virtual Warehouses Warehouse { get { return ClassFrame.db.Database.SqlQuery<Warehouses>($"select * from Nomenclature.dbo.Warehouses where idWarehouse = {idWarehouse}").First(); } }
        public virtual ExpenseComposition Expense { get { return ClassFrame.db.ExpenseComposition.FirstOrDefault(x => x.IdExpenseComposition == idComposition); } }
        public virtual Employee User { get { return ClassFrame.db.Employee.FirstOrDefault(x => x.IdEmployee == idUser); } }
    
    }
}
