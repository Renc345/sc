﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesOfMaterials.Classes
{
    public class Users
    {
        public static Users GetUsers { get; set; }
        public int ID { get; set; }
        public string FIO { get; set; }
        public string Login_Employee { get; set; }
        public string Password_Employee { get; set; }
        public string Nazv_type { get; set; }
        public int IdTypesEmployee { get; set; }
        public Users(Employee employee)
        {
            ID = employee.IdEmployee;
            FIO = employee.FIO;
            Login_Employee = employee.Login_Employee;
            Password_Employee = employee.Password_Employee;
            Nazv_type = employee.TypesEmployee.Nazv_type;
            IdTypesEmployee = employee.TypesEmployee.IdTypesEmployee;
            GetUsers = this;

        }
    }
}
