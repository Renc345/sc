﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media.Media3D;

namespace SalesOfMaterials.Classes
{
    public class Materials
    {
        private string plan;
        public int idMaterial { get; set; }
        public string Name { get; set; }
        public string DrawingNumber
        {
            get
            {
                if (idType == 4) return "Отсутствует";
                return plan;
            }
            set { plan = value; }
        }

        public int idType { get; set; }
        public string NameType { get; set; }
        public virtual Types Type { get { return ClassFrame.db.Database.SqlQuery<Types>($"select * from Nomenclature.dbo.Types where idType = {idType}").First(); } }
    }
}
